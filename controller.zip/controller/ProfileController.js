const mongoose = require('mongoose');
const ProfileSchema = require('../models/Profile');
const ProfileService = require('../services/ProfileService');
const config = require('config')

exports.Get = (req, res, next) => {
    userId = req.tokenData.data._id;
console.log(userId)
    ProfileService.GetById(userId, (err, data) => {
            res.status(200).json({
                success:true,
                profile:data
            })
    })
}

exports.AddNew = (req, res, next) =>{
    userId = req.tokenData.data._id;
    let newVendorEnquiry=new ProfileSchema({
        _id : new mongoose.Types.ObjectId(),
        community : req.body.community,
        user_id : userId
    });
    console.log(newVendorEnquiry)
    ProfileService.AddNew(newVendorEnquiry, (err, data)=>{
        if(err){
            const errorMsg=["error 1", "error 2"];
            console.log(errorMsg);
            return res.status(200).json({
                success:false,
                errorMsg,
                err
            })
        }else{
            console.log(data);
            return res.status(200).json({
                success:true,
                message:"You have Successfully Registered with Community",
                data
            })
        }
    })
}

exports.Update = (req, res, next) => {
    const id = req.params.id;
    const updateOps={};

    ProfileService.Update(id, req.body, (err, data)=>{
        if(err){
            console.log(err);
            res.status(500).json({
                success:false,
                error:err
            })
        }else{
            res.status(200).json({
                success:true,
                message:"Vendor status update Successfully."
            })
        }
    })
}

exports.Delete = (req, res, next) => {
    ProfileService.Delete(req.params.id, (err, data)=>{
        if(err){
            console.log(err);
            res.status(500).json({
                success:false,
                error:err
            })
        }else{
            res.status(200).json({
                success:true,
                message:"Vendor deleted Successfully."
            })
        }
    })   
}
