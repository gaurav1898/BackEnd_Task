const mongoose = require('mongoose');
const SellerSchema = require('../models/Seller');
const SellerService = require('../services/SellerService');
const config = require('config')
const UserSchema = require('../models/User');

const UserService = require('../services/UserService');

exports.GetAll = (req, res, next) => {
    SellerService.GetAll((err, data) => {
        if(data.length<=0){
            res.status(201).json({
                success: false,
                message: "There are no Community to show, Please add a Connection Type"
            })
        }else{
            res.status(200).json({
                success:true,
                data
            })
        }
    })
} 

exports.GetStatusCount = (req, res, next) => {
    console.log("Changing community status")
    status_id=req.params.status_id;
    SellerService.GetCountByStatus(status_id, (err, data) => {
        console.log(data)
        if(data>=0){
            statusSearch = "";
            if(status_id==0){
                statusSearch = "InActive"
            }else{
                statusSearch = "Active"
            }
            console.log(data)
            res.status(200).json({
                success:true,
                count:data
            })
        }else{
            res.status(400).json({
                success:false,
                err
            })
        }
    })
} 

exports.AddNew = (req, res, next) =>{
    userId = req.tokenData.data._id;
    let newCommunity=new SellerSchema({
        _id : new mongoose.Types.ObjectId(),
        community_id: req.body.community_id,
        productType_id: req.body.productType_id,
        status : req.body.status,
        user_id:userId
    });
    let newUser=new UserSchema({
        _id : new mongoose.Types.ObjectId(),
        email : req.body.email,
        password : req.body.password,
        contact : req.body.contact,
        name: req.body.name,
        roles : ["Seller"],
        salt : config.get('App.SALT_ROUNDS'),
        provider : 'Local'
    });
    UserService.addUser(newUser, (err, user) => {
        //Validating the Inputs
        if(err){
            let message = "";
            if(err.errors.name) message = "Username is already taken.";
            if(err.errors.email) message += "Invalid Email Address or Email Address is already taken.";
            if(err.errors.name) message += "Mobile number already exists.";
            if(err.error.username || err.error.email){
                SellerService.AddNew(newCommunity, (err, data)=>{
                    if(err){
                        console.log(err);
                        return res.status(400).json({
                            success: false,
                            err
                        })
                    }else{
                        console.log(data);
                        //need to store seller account id inside user table
                        return res.json({
                            success: true,
                            message: "Seller has registered Successfully."
                        })
                    }
                })

            }else{
                return res.status(400).json({
                    success: false,
                    message: message,
                    err
                })     
            }

        }
        else{
            console.log("Sending success message of user registration")
            SellerService.AddNew(newCommunity, (err, data)=>{
                if(err){
                    console.log(err);
                    return res.status(400).json({
                        success: false,
                        err
                    })
                }else{
                    console.log(data);
                    //need to store seller account id inside user table
                    return res.json({
                        success: true,
                        message: "Seller has registered Successfully."
                    })
                }
            })            

        }
    })


    console.log(newCommunity)

}

exports.Update = (req, res, next) => {
    const id = req.params.id;
    const updateOps={};
    console.log(id)
    SellerService.Update(id, req.body, (err, data)=>{
        if(err){
            console.log(err);
            res.status(400).json({
                success:false,
                error:err
            })
        }else{
            res.status(200).json({
                success:true,
                message:"Connection Type Updated Successfully."
            })
        }
    })
}

exports.Delete = (req, res, next) => {
    SellerService.Delete(req.params.id, (err, data)=>{
        if(err){
            console.log(err);
            res.status(400).json({
                success:false,
                error:err
            })
        }else{
            res.status(200).json({
                success:true,
                message:"Connection Type Deleted Successfully."
            })
        }
    })   
}

exports.GetById = (req, res, next) => {
    SellerService.GetById(req.params.id, (err, data) => {
        if(err){
            console.log(err);
            res.status(400).json({
                success:false,
                error:err
            })
        }else{
            res.status(200).json({
                success:true,
                data
            })
        }
    })
}

exports.ChangeStatus = (req, res, next) => {
    SellerService.GetById(req.params.id, (err, data0) =>{
        let _status=data0.status;
       //  console.log(_status);
         if(_status==="0"){
             _status="1"
         }else if(_status === "1"){
             _status="0"
         }else{
             res.json({
                 success:false,
                 message:"Oops something went!! Please try later or contact your technical support."
             })
         }
 
         SellerService.updateCommunityStatus(data0._id, _status, (err, data)=>{
             if(err) throw err;
             
             res.json({
                 success:true,
                 message:'Community Account has been "'+_status+'" successfully'
             })
         }) 
    })
}