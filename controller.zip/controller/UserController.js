const mongoose = require('mongoose');
const UserSchema = require('../models/User');

const UserService = require('../services/UserService');

const config = require('config')
const Token = require('../handler/genToken');
const roleList = require('../seed/Roles');

exports.AddUser = (req, res, next) => {
    console.log("Creating user")
    let newUser=new UserSchema({
        _id : new mongoose.Types.ObjectId(),
        email : req.body.email,
        password : req.body.password,
        contact : req.body.contact,
        roles : ["Su"],
        salt : config.get('App.SALT_ROUNDS'),
        provider : 'Local'
    });
    UserService.addUser(newUser, (err, user) => {
        //Validating the Inputs
        if(err){
            let message = "";
            if(err.errors.username) message = "Username is already taken.";
            if(err.errors.email) message += "Invalid Email Address or Email Address is already taken.";
            if(err.errors.contact) message += "Mobile number already exists.";
            //Throwing the error to user
            return res.status(400).json({
                success: false,
                message: message,
                err
            })
        }
        else{
            console.log("Sending success message of user registration")
            return res.json({
                success: true,
                message: "You have been registered Successfully."
            })
        }
    })
}

exports.AddCustomer = (req, res, next) => {
    console.log("Creating user")
    let newUser=new UserSchema({
        _id : new mongoose.Types.ObjectId(),
        email : req.body.email,
        password : req.body.password,
        contact : req.body.contact,
        roles : ["User"],
        salt : config.get('App.SALT_ROUNDS'),
        provider : 'Local'
    });
    UserService.addUser(newUser, (err, user) => {
        //Validating the Inputs
        if(err){
            let message = "";
            if(err.errors.username) message = "Username is already taken.";
            if(err.errors.email) message += "Invalid Email Address or Email Address is already taken.";
            if(err.errors.contact) message += "Mobile number already exists.";
            //Throwing the error to user
            return res.status(400).json({
                success: false,
                message: message,
                err
            })
        }
        else{
            console.log("Sending success message of user registration")
            //Send Welcome Email
            //Send Verification Email to activate account status
            return res.json({
                success: true,
                message: "You have been registered Successfully."
            })
        }
    }) 
}
exports.AddVendor = (req, res, next) => {
    console.log("Creating user")
    let newUser=new UserSchema({
        _id : new mongoose.Types.ObjectId(),
        email : req.body.email,
        password : req.body.password,
        contact : req.body.contact,
        roles : ["Seller"],
        salt : config.get('App.SALT_ROUNDS'),
        provider : 'Local'
    });
    UserService.addUser(newUser, (err, user) => {
        //Validating the Inputs
        if(err){
            let message = "";
            if(err.errors.username) message = "Username is already taken.";
            if(err.errors.email) message += "Invalid Email Address or Email Address is already taken.";
            if(err.errors.contact) message += "Mobile number already exists.";
            //Throwing the error to user
            return res.status(400).json({
                success: false,
                message: message,
                err
            })
        }
        else{
            console.log("Sending success message of user registration")
            //Send Welcome Email
            //Send Verification Email to activate account status
            return res.json({
                success: true,
                message: "You have been registered Successfully."
            })
        }
    }) 
}

exports.SignIn = (req, res, next) =>{
    console.log("processing login")
    UserService.findUser(req.body.email, req.body.email,(err, user) => {
        if(err){
            console.log(err)
            return res.status(400).json({
                success:false,
                message:err
            })
        }
        if(!user){
            return res.status(400).json({
                success:false,
                message:"Invalid Authentication, Please check your login name and password"
            });
        } 
        UserService.comparePassword(req.body.password, user.password, (err, isMatch) => {
            console.log(user)
            if(err) throw err;
            if(isMatch){
                const token = Token.generateToken(user);
                console.log(token);
                return res.status(200).json({
                    success: true,
                    user:user,
                    role:user.roles,
                    token : "JWT "+ token
                })
            }else{
                return res.status(400).json({
                    success : false,
                    message : "Wrong Password"
                })
            }
        })
    })
}

exports.FindUser = (req, res, next) =>{
    UserService.findUser(req.params.search,(err, user) => {

        // if(err) throw err;
        if(user){
            return res.json({
                success:true,
                message: "User is already registered"
            })
        }else{
            return res.json({
                success: true,
                message: "User is not registered yet. Register Now"
            })
        }
    })
}

exports.validateEmail = (req, res, next) => {
    const email = req.body.email;
    console.log(email);
    UserService.validateEmail(email, (err, user)=>{
        if(err) throw err;
        if(user){
            return res.json({
                success:false,
                message: "Email Id is already in use"
            })
        }else{
            return res.json({
                success: true,
                message: "No Email id is registered with this Email Address."
            })
        }
    })
}

exports.GetAllUser = (req, res, next) => {
    console.log(req.params.role);
    // res.json(res.params.role)
    if(req.params.role=="all"){
        UserService.getAllUser( (err, users) => {
            if(users.length<=0){
                res.json({
                    success: false,
                    message: "There are no user to show, Please add a user"
                })
            }else{
                res.json({
                    success: true,
                    count: users.length,
                    users
                })
            }
        })
    }else{
        UserService.getAllUser(req.params.role, (err, users) => {
            console.log(users)
            if(users.length<=0){
                res.json({
                    success: false,
                    message: "There are no user to show, Please add a user"
                })
            }else{
                res.json({
                    success: true,
                    count: users.length,
                    users
                })
            }

        })
    }

}

exports.GetUserByID = (req, res, next) => {
    UserService.GetUserByID(req.params.id, (err, user) =>{
        res.json({
            success:true,
            user
        })
    })
}

exports.GetUserByStatus = (req, res, next) => {
    UserService.GetUserByStatus(req.params.status, (err, user) =>{
        res.json({
            success:true,
            user
        })
    })
}

exports.GetUserByRole = (req, res, next) => {
    UserService.GetUserByRole(req.params.role, (err, users) => {
        if(err){
            console.log(err)
            res.json({
                success: false,
                err
            })
        }else{
            console.log(users)
            if(users.roles.indexOf(role)){
                console.log("filtered")
                res.json({
                    success: true,
                    count: user.length,
                    users
                })
            }else{
                res.json({
                    success: true,
                    error: "Unable to put filter"                
                })
            }
        }

    })
}

exports.GetAllRoles = (req, res, next) => {
    console.log(roleList)
        res.json({
            status: true,
            count: roleList.ROLES.length,
            roles: roleList.ROLES
        })
}  