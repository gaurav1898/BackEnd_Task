const mongoose = require('mongoose');
const CommunitySchema = require('../models/Community');
const CommunityService = require('../services/CommunityService');
const config = require('config')

exports.GetAll = (req, res, next) => {
    CommunityService.GetAll((err, data) => {
        if(data.length<=0){
            res.status(201).json({
                success: false,
                message: "There are no Community to show, Please add a Connection Type"
            })
        }else{
            res.status(200).json({
                success:true,
                data
            })
        }
    })
} 

exports.GetStatusCount = (req, res, next) => {
    console.log("Changing community status")
    status_id=req.params.status_id;
    CommunityService.GetCountByStatus(status_id, (err, data) => {
        console.log(data)
        if(data>=0){
            statusSearch = "";
            if(status_id==0){
                statusSearch = "InActive"
            }else{
                statusSearch = "Active"
            }
            console.log(data)
            res.status(200).json({
                success:true,
                count:data
            })
        }else{
            res.status(400).json({
                success:false,
                err
            })
        }
    })
} 

exports.AddNew = (req, res, next) =>{
    userId = req.tokenData.data._id;
    let newCommunity=new CommunitySchema({
        _id : new mongoose.Types.ObjectId(),
        name : req.body.community,
        note : req.body.note,
        details:req.body.details,
        address : req.body.address,
        location : req.body.location,
        contact: req.body.contact,
        status : req.body.status,
        user_id:userId
    });
    console.log(newCommunity)
    CommunityService.AddNew(newCommunity, (err, data)=>{
        if(err){
            console.log(err);
            return res.status(400).json({
                success: false,
                err
            })
        }else{
            console.log(data);
            return res.status(200).json({
                success:true,
                message:"Community Registered successfully",
                data
            })
        }
    })
}

exports.Update = (req, res, next) => {
    const id = req.params.id;
    const updateOps={};
    console.log(id)
    CommunityService.Update(id, req.body, (err, data)=>{
        if(err){
            console.log(err);
            res.status(400).json({
                success:false,
                error:err
            })
        }else{
            res.status(200).json({
                success:true,
                message:"Connection Type Updated Successfully."
            })
        }
    })
}

exports.Delete = (req, res, next) => {
    CommunityService.Delete(req.params.id, (err, data)=>{
        if(err){
            console.log(err);
            res.status(400).json({
                success:false,
                error:err
            })
        }else{
            res.status(200).json({
                success:true,
                message:"Connection Type Deleted Successfully."
            })
        }
    })   
}

exports.GetById = (req, res, next) => {
    CommunityService.GetById(req.params.id, (err, data) => {
        if(err){
            console.log(err);
            res.status(400).json({
                success:false,
                error:err
            })
        }else{
            res.status(200).json({
                success:true,
                data
            })
        }
    })
}

exports.ChangeStatus = (req, res, next) => {
    CommunityService.GetById(req.params.id, (err, data0) =>{
        let _status=data0.status;
       //  console.log(_status);
         if(_status==="0"){
             _status="1"
         }else if(_status === "1"){
             _status="0"
         }else{
             res.json({
                 success:false,
                 message:"Oops something went!! Please try later or contact your technical support."
             })
         }
         CommunityService.updateCommunityStatus(data0._id, _status, (err, data)=>{
             if(err) throw err;
             
             res.json({
                 success:true,
                 message:'Community Account has been "'+_status+'" successfully'
             })
         }) 
    })
}