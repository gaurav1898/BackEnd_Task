const mongoose = require('mongoose');
const config = require('config')

exports.Get = (req, res, next) => {
    VendorRegEnquiryService.GetAll((err, data) => {
        if(data.length<=0){
            res.status(201).json({
                success: false,
                message: "There are no Vendor Request yet to show"
            })
        }else{
            res.status(200).json({
                success:true,
                data
            })
        }
    })
}

exports.AddNew = (req, res, next) =>{
    // let newVendorEnquiry=new VendorRegEnquirySchema({
    //     _id : new mongoose.Types.ObjectId(),
    //     name : req.body.name,
    //     contact : req.body.contact,
    //     email : req.body.email,
    //     tradeName : req.body.tradeName,
    //     emirate : req.body.emirate,
    //     location : req.body.location,
    //     website : req.body.website,
    //     status : req.body.status,

    // });
    // console.log(newVendorEnquiry)
    // VendorRegEnquiryService.AddNew(newVendorEnquiry, (err, data)=>{
    //     if(err){
    //         const errorMsg=["error 1", "error 2"];
    //         console.log(errorMsg);
    //         return res.status(200).json({
    //             success:false,
    //             errorMsg,
    //             err
    //         })
    //     }else{
            
    //         console.log(data);
    //         return res.status(200).json({
    //             success:true,
    //             message:"Hello, "+data.name + "!! Thanks for registering with MumMeals. Our team will connect you soon.",
    //             data
    //         })
    //     }
    // })
        res.json({
            'message': 'File uploaded successfully'
        });
}

exports.Update = (req, res, next) => {
    const id = req.params.id;
    const updateOps={};

    VendorRegEnquiryService.Update(id, req.body, (err, data)=>{
        if(err){
            console.log(err);
            res.status(500).json({
                success:false,
                error:err
            })
        }else{
            res.status(200).json({
                success:true,
                message:"Vendor status update Successfully."
            })
        }
    })
}

exports.Delete = (req, res, next) => {
    VendorRegEnquiryService.Delete(req.params.id, (err, data)=>{
        if(err){
            console.log(err);
            res.status(500).json({
                success:false,
                error:err
            })
        }else{
            res.status(200).json({
                success:true,
                message:"Vendor deleted Successfully."
            })
        }
    })   
}

exports.GetById = (req, res, next) => {
    VendorRegEnquiryService.GetById(req.params.id, (err, data) => {
        if(err){
            console.log(err);
            res.status(500).json({
                success:false,
                error:err
            })
        }else{
            res.status(200).json({
                success:true,
                data
            })
        }
    })
}

exports.ChangeStatus = (req, res, next) => {
    VendorRegEnquiryService.GetById(req.params.id, (err, data0) =>{
        let _status=data0.status;
       //  console.log(_status);
         if(_status==="0"){
             _status="1"
         }else if(_status === "1"){
             _status="0"
         }else{
             res.json({
                 success:false,
                 message:"Oops something went!! Please try later or contact your technical support."
             })
         }
         VendorRegEnquiryService.updateVendorRegEnquiryStatus(data0._id, _status, (err, data)=>{
             if(err) throw err;
             
             res.json({
                 success:true,
                 message:'Vendor Enquiry status has been "'+_status+'" successfully'
             })
         }) 
    })
}